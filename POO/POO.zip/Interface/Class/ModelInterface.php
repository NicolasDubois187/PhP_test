<?php

interface modelInterface
{
  public function getId();
  public static function getTotalUser();
}
