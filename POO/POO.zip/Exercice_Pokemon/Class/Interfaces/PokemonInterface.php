<?php

interface PokemonInterface
{
  public function evolue();
}
